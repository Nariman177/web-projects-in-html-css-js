$(function(el) {
  $(el).circleProgress({fill: {color: 'blue'}})
  .on('circle-animation-progress', function(event, progress, stepValue) {
  $(this).find('strong').text(String(stepValue.toFixed(2)).substr(2)+'%');
  });
}('.round'));
$(function(el) {
  $(el).circleProgress({fill: {color: 'purple'}})
  .on('circle-animation-progress', function(event, progress, stepValue) {
  $(this).find('strong').text(String(stepValue.toFixed(2)).substr(2)+'%');
  });
}('.round2'));
$(function(el) {
  $(el).circleProgress({fill: {color: 'green'}})
  .on('circle-animation-progress', function(event, progress, stepValue) {
  $(this).find('strong').text(String(stepValue.toFixed(2)).substr(2)+'%');
  });
}('.round3'));
$(function(el) {
  $(el).circleProgress({fill: {color: 'orange'}})
  .on('circle-animation-progress', function(event, progress, stepValue) {
  $(this).find('strong').text(String(stepValue.toFixed(2)).substr(2)+'%');
  });
}('.round4'));
